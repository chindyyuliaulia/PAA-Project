import pygame
import sys
import math
import random

pygame.init()

WINDOW_WIDTH = 1200
WINDOW_HEIGHT = 800

BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
RED = (255, 0, 0)
GRAY = (200, 200, 200)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

window = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Smart Kurir")

# Load gambar dan resize
def load_and_resize(path, size):
    img = pygame.image.load(path).convert_alpha()
    return pygame.transform.scale(img, size)

try:
    motor_imgs = {
        "kanan": load_and_resize("motor_kanan.png", (35, 35)),
        "kiri": load_and_resize("motor_kiri.png", (35, 35)),
        "atas": load_and_resize("motor_atas.png", (35, 35)),
        "bawah": load_and_resize("motor_bawah.png", (35, 35)),
    }
    flag_kuning = load_and_resize("flag_kuning.png", (30, 30))
    flag_merah = load_and_resize("flag_merah.png", (30, 30))
except Exception as e:
    print("Error loading images:", e)
    sys.exit()

map_image = None
kurir_pos = [100, 100]
kurir_speed = 2
kurir_arah = "kanan"

source_pos = [300, 300]
dest_pos = [900, 600]

font = pygame.font.SysFont(None, 28)
load_btn = pygame.Rect(20, 20, 150, 40)
acak_btn = pygame.Rect(190, 20, 150, 40)
start_btn = pygame.Rect(360, 20, 150, 40)

kurir_jalan = False

def draw_button(rect, text):
    pygame.draw.rect(window, GRAY, rect)
    label = font.render(text, True, BLACK)
    label_rect = label.get_rect(center=rect.center)
    window.blit(label, label_rect)

def random_position():
    return [random.randint(100, WINDOW_WIDTH - 100), random.randint(100, WINDOW_HEIGHT - 100)]

clock = pygame.time.Clock()
running = True

while running:
    window.fill(WHITE)

    if map_image:
        window.blit(map_image, (0, 0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.MOUSEBUTTONDOWN:
            if load_btn.collidepoint(event.pos):
                try:
                    map_image = pygame.image.load("peta.png")
                    print("Peta dimuat.")
                except pygame.error:
                    print("Gagal memuat gambar peta.")
            elif acak_btn.collidepoint(event.pos):
                kurir_pos = random_position()
                source_pos = random_position()
                dest_pos = random_position()
                kurir_jalan = False
                print("Posisi acak berhasil.")
            elif start_btn.collidepoint(event.pos):
                kurir_pos = list(source_pos)
                kurir_jalan = True
                print("Kurir mulai berjalan otomatis.")

    # Gerakan otomatis kurir ke tujuan
    if kurir_jalan:
        dx = dest_pos[0] - kurir_pos[0]
        dy = dest_pos[1] - kurir_pos[1]
        distance = math.hypot(dx, dy)
        if distance > 3:
            dx /= distance
            dy /= distance
            kurir_pos[0] += dx * kurir_speed
            kurir_pos[1] += dy * kurir_speed

            if abs(dx) > abs(dy):
                kurir_arah = "kanan" if dx > 0 else "kiri"
            else:
                kurir_arah = "bawah" if dy > 0 else "atas"
        else:
            kurir_jalan = False
            print("Kurir sudah sampai tujuan!")

    keys = pygame.key.get_pressed()
    if keys[pygame.K_RIGHT]:
        kurir_pos[0] += kurir_speed
        kurir_arah = "kanan"
    elif keys[pygame.K_LEFT]:
        kurir_pos[0] -= kurir_speed
        kurir_arah = "kiri"
    elif keys[pygame.K_UP]:
        kurir_pos[1] -= kurir_speed
        kurir_arah = "atas"
    elif keys[pygame.K_DOWN]:
        kurir_pos[1] += kurir_speed
        kurir_arah = "bawah"

    draw_button(load_btn, "Load Peta")
    draw_button(acak_btn, "Acak Posisi")
    draw_button(start_btn, "Mulai")

    window.blit(flag_kuning, source_pos)
    window.blit(flag_merah, dest_pos)
    window.blit(motor_imgs[kurir_arah], kurir_pos)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()