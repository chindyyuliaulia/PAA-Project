import pygame
import sys
import math
import random

pygame.init()

WINDOW_WIDTH = 1200
WINDOW_HEIGHT = 800

BLUE = (0, 0, 255)
YELLOW = (255, 255, 0)
RED = (255, 0, 0)
GRAY = (200, 200, 200)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

window = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
pygame.display.set_caption("Smart Kurir")

map_image = None
kurir_pos = [100, 100]
kurir_angle = 90
kurir_speed = 2

source_flag = pygame.Rect(300, 300, 20, 20)
dest_flag = pygame.Rect(900, 600, 20, 20)

font = pygame.font.SysFont(None, 28)
load_btn = pygame.Rect(20, 20, 150, 40)
acak_btn = pygame.Rect(190, 20, 150, 40)
start_btn = pygame.Rect(360, 20, 150, 40)

kurir_jalan = False  # status apakah kurir sedang bergerak otomatis

def draw_triangle(surface, pos, angle, size=20):
    x, y = pos
    angle_rad = math.radians(angle)
    points = [
        (x + math.cos(angle_rad) * size, y + math.sin(angle_rad) * size),
        (x + math.cos(angle_rad + 2.5) * size, y + math.sin(angle_rad + 2.5) * size),
        (x + math.cos(angle_rad - 2.5) * size, y + math.sin(angle_rad - 2.5) * size)
    ]
    pygame.draw.polygon(surface, BLUE, points)

def draw_button(rect, text):
    pygame.draw.rect(window, GRAY, rect)
    label = font.render(text, True, BLACK)
    label_rect = label.get_rect(center=rect.center)
    window.blit(label, label_rect)

def random_position():
    return [random.randint(100, WINDOW_WIDTH - 100), random.randint(100, WINDOW_HEIGHT - 100)]

clock = pygame.time.Clock()
running = True

while running:
    window.fill(WHITE)

    if map_image:
        window.blit(map_image, (0, 0))

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif event.type == pygame.MOUSEBUTTONDOWN:
            if load_btn.collidepoint(event.pos):
                try:
                    map_image = pygame.image.load("peta.png")
                    print("Peta dimuat.")
                except pygame.error:
                    print("Gagal memuat gambar peta.")
            elif acak_btn.collidepoint(event.pos):
                kurir_pos = random_position()
                source_flag.topleft = random_position()
                dest_flag.topleft = random_position()
                kurir_jalan = False
                print("Posisi acak berhasil.")
            elif start_btn.collidepoint(event.pos):
                kurir_pos = list(source_flag.center)
                kurir_jalan = True
                print("Kurir mulai berjalan otomatis.")

    # Gerakan otomatis kurir ke tujuan
    if kurir_jalan:
        dx = dest_flag.centerx - kurir_pos[0]
        dy = dest_flag.centery - kurir_pos[1]
        distance = math.hypot(dx, dy)
        if distance > 3:
            dx /= distance
            dy /= distance
            kurir_pos[0] += dx * kurir_speed
            kurir_pos[1] += dy * kurir_speed
            kurir_angle = math.degrees(math.atan2(dy, dx))
        else:
            kurir_jalan = False
            print("Kurir sudah sampai tujuan!")

    keys = pygame.key.get_pressed()
    if keys[pygame.K_RIGHT]:
        kurir_pos[0] += kurir_speed
        kurir_angle = 0
    elif keys[pygame.K_LEFT]:
        kurir_pos[0] -= kurir_speed
        kurir_angle = 180
    elif keys[pygame.K_UP]:
        kurir_pos[1] -= kurir_speed
        kurir_angle = 270
    elif keys[pygame.K_DOWN]:
        kurir_pos[1] += kurir_speed
        kurir_angle = 90

    draw_button(load_btn, "Load Peta")
    draw_button(acak_btn, "Acak Posisi")
    draw_button(start_btn, "Mulai")

    pygame.draw.rect(window, YELLOW, source_flag)
    pygame.draw.rect(window, RED, dest_flag)
    draw_triangle(window, kurir_pos, kurir_angle)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()